puts "What is the first number?"
num1 = gets.chomp.to_i
puts "What is the second number?"
num2 = gets.chomp.to_i

puts "The sum of the numbers #{num1} and #{num2} is #{num1+num2}."