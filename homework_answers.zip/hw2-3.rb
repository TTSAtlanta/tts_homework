def add_it_up(num1, num2)
  num1 + num2
end

def multiply_it(num1, num2)
  num1 * num2
end

def divide_it(num1, num2)
  num1 / num2
end

def subtract_it(num1, num2)
  num1 - num2
end

puts add_it_up(808,1616)

puts multiply_it(8,8)

puts divide_it(24,8)

puts subtract_it(109483434,572885)